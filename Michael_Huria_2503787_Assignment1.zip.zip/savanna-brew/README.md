Name: Michael Huria

Reg No: 2503787

Course:DBIT

Assignment: HTML \& CSS - Savanna Brew Café Website



Validation:

I validated all HTML pages (index, about, menu, gallery, contact and events)

using the W3C Markup Validator, and css/style.css using the W3C CSS Validator.

warnings:

1 **CSS**

Due to their dynamic nature, CSS variables are currently not statically checked

5-Due to their dynamic nature, CSS variables are currently not statically checked

24-Due to their dynamic nature, CSS variables are currently not statically checked



Bonus features:

\- Extra page: events.html

\- CSS animation: hero text fade-in

\- Dark mode





